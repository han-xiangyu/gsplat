# Differential Gaussian Rasterization in Grendal-GS

Used as the cuda rasterization engine for [Grendal-GS](https://github.com/nyu-systems/Grendal-GS). 
